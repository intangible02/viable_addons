DBM:RegisterMapSize("TheEyeofEternity", 1, 430.07006836, 286.713012695) -- The Eye of Eternity
