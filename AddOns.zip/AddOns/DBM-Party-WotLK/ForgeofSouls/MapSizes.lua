DBM:RegisterMapSize("TheForgeofSouls", 1, 1448.09985351, 965.40039062) -- The Forge of Souls
