﻿--[[
	Bagnon_Tooltips Localization
		Russian: Russian Localization by kutensky
--]]

if ( GetLocale() == "ruRU" ) then
	BAGNON_NUM_BAGS = 'В сумке: %d'
	BAGNON_NUM_BANK = 'В банке: %d'
	BAGNON_EQUIPPED = 'На персонаже'
end